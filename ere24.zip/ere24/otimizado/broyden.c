#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <likwid.h>

#include "utils.h"
#include "matriz.h"

#define MAX_ITER 25

int main(int argc, char *argv[]) {
    
    FILE *output = stdout;
    for (int i = 0; i < argc; i++) {
        if (strcmp(argv[i], "-o") == 0) {
            if (i + 1 < argc) {
                output = fopen(argv[i + 1], "wb+");
                if (!output) {
                    return 1;
                }
            }
        }
    }
    
    int n, max = MAX_ITER;
    double xo, epsilon;

    if(scanf("%d %lf %lf,", &n, &xo, &epsilon)<=0){
        fprintf(output, "Erro na leitura de dados inciais.\n");
    }

    // Cria vetor das variáveis X iniciais
    double *x = malloc(n * sizeof(double));
    verifica_alocacao(x, output);

    // Inicializa vetor com x0 em todos 
    for (size_t i = 0; i < n; i++){
        x[i] = xo;
    }

    // Resolução da Matriz de Broyden com Método de Newton
    LIKWID_MARKER_INIT;
    rtime_t tempoNewton = 0, tempoJacobiana = 0, tempoSL = 0;
    x = metodoDeNewton(output, x, max, epsilon, n, &tempoNewton, &tempoJacobiana, &tempoSL);
    LIKWID_MARKER_CLOSE;

    
    if (x == NULL) {
        fprintf(output, "Não foi possível encontrar uma solução.\n");
        return 1;
    } else {
        fprintf(output, "Solução para sistema encontrado.\n");
        imprimirVetor(output, x, n);
    }
    imprimirTempos(output, tempoNewton, tempoJacobiana, tempoSL);

    fclose(output);
    return 0;
}