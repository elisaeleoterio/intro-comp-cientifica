#ifndef MATRIZ_H
#define MATRIZ_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <likwid.h>

#include "utils.h"

double *resolveBroyden(int n, double *x);
double *calcularJacobiana(double *x, int n, rtime_t *tempJacobiana);
double *resolverSistemaLinear(double *d, int n, double *F, rtime_t *tempSL, FILE *output, double epsilon, int max_iter);
double *metodoDeNewton(FILE *output, double *x, int max, double epsilon, int n, rtime_t *tempoNewton, rtime_t *tempoJacobiana, rtime_t *tempoSL);

#endif